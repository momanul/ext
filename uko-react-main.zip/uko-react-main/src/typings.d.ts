declare module "stylis-plugin-rtl" {
  const noTypesYet: any;
  export default noTypesYet;
}
