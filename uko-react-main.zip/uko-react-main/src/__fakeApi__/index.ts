import Mock from "__fakeApi__/mock";
// ====================================================
import "./dataTable";
import "./users";

Mock.onAny().passThrough();
